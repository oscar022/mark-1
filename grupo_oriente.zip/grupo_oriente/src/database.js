const mongoose = require("mongoose");
const { connect } = require("mongoose");
(async()=>{try{
    const db = await connect("mongodb://localhost:27017/crud-mongo")  //direccion de mongoDB
    console.log("DB connected to", db.connection.name);
}catch(error){
    console.error("error");
}
})();


module.exports = appdata; //exporto el modulo app