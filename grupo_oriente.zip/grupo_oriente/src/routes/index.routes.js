const { Router } = require("express");
const router = Router(); //creo el modulo router

router.get("/", (req, res) => {
  res.render('index'); //render llama el texto de ./views/index.html
});

router.get("/ingles", (req, res) => {
  res.render('ingles'); //render llama el texto de ./views/index.html
});

router.get("/espanol", (req, res) => {
  res.render('espanol'); //render llama el texto de ./views/index.html
});

router.get("/iniciar_sesion", (req, res) => {
  res.render('./views/español/iniciar_sesion'); //render llama el texto de ./views/index.html
});


module.exports = router; //exporto el modulo router
